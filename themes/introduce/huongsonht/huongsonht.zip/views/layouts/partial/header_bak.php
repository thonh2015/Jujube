
<div class="bg-box-top">
        <div class="box-top ">
            <div class="container clearfix">
                <div class="logo">
                    <h1>
                        <a href="<?php echo Yii::app()->homeUrl; ?>" title="<?php echo Yii::app()->siteinfo['site_title']; ?>">
                            <img alt="Về trang chủ" src="<?php echo Yii::app()->siteinfo['site_logo']; ?>" />
                            <span class="hide-text"><?php echo Yii::app()->siteinfo['site_title']; ?></span>
                        </a>
                    </h1>
                </div>
                
                <!--end-box-right--> 
            </div>
            <!--end-container-->
             
        </div>
        <!--end-box-top--> 
    </div>
<div id="header">
    <div class="cont-header clearfix">
    
        <div id="header_banner">
            <?php
            $this->widget('common.widgets.wglobal.wglobal', array('position' => Widgets::POS_TOP_HEADER));
            ?>
        </div>
        <div class="clear"></div>
<nav id="nav">
            <div class="box-menu">
                <?php
                $this->widget('common.widgets.wglobal.wglobal', array('position' => Widgets::POS_HEADER));
                ?>
            </div>
        </nav>
        <div id="bottom-header">

            <div class="date">
                <?php
                date_default_timezone_set('Asia/Ho_Chi_Minh');
                $weekday = date("l");
                $weekday = strtolower($weekday);
                switch ($weekday) {
                    case 'monday':
                        $weekday = 'Thứ hai';
                        break;
                    case 'tuesday':
                        $weekday = 'Thứ ba';
                        break;
                    case 'wednesday':
                        $weekday = 'Thứ tư';
                        break;
                    case 'thursday':
                        $weekday = 'Thứ năm';
                        break;
                    case 'friday':
                        $weekday = 'Thứ sáu';
                        break;
                    case 'saturday':
                        $weekday = 'Thứ bảy';
                        break;
                    default:
                        $weekday = 'Chủ nhật';
                        break;
                }
                echo $weekday . ', ngày ' . date('d/m/Y');
                ?>
            </div>
            <div class="welcome">
                <?php
                $this->widget('common.widgets.wglobal.wglobal', array('position' => Widgets::POS_HEADER_BOTTOM));
                ?>
            </div>
            <div id="search-header">
                <?php
                $this->widget('common.widgets.wglobal.wglobal', array('position' => Widgets::POS_HEADER_RIGHT));
                ?>
            </div>
        </div>
        <div class="clear"></div>
        
    </div>
</div>