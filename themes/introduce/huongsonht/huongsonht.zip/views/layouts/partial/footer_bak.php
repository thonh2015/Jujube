<div class="footer" id="footer">
    <div class="menu-bottom">
        <ul>

            <li><a href="/gioi-thieu" rel="nofollow">Giới thiệu</a></li>

            <li><a href="/huong-dan-su-dung" rel="nofollow">Hướng dẫn sử dụng</a></li>

            <li><a href="/quy-dinh-chinh-sach" rel="nofollow">Quy định, chính sách</a></li>

            <li><a href="/quang-cao" rel="nofollow">Quảng cáo</a></li>
            <li><a href="/lien-he" rel="nofollow">Tuyển dụng</a></li>
            <li><a href="/lien-he" rel="nofollow">Liên hệ</a></li>

        </ul>
        <div class="clear"></div>
    </div>

    <div class="box clearfix">
        <div class="row">
            <div class="footer-nd">
            <?php
            if (Yii::app()->siteinfo['footercontent']) {
                echo Yii::app()->siteinfo['footercontent'];
            }            ?>
            </div>
            <!--
            <div class="footer-nd col-xs-5 col-md-5">
                <?php
                //$this->widget('common.widgets.wglobal.wglobal', array('position' => Widgets::POS_FOOTER_BLOCK1));
                ?>
            </div>
            <div class="footer-nd col-xs-3 col-md-3">
            </div>
            <div class="footer-nd col-xs-4 col-md-4">
                <?php
                //if (Yii::app()->siteinfo['footercontent']) {
                //    echo Yii::app()->siteinfo['footercontent'];
                //}
                ?>
            </div>
            -->
        </div>
    </div>
    <div class="designby"><a href="http://jujube.com.vn" title="Thiết kế web, thiết kế web chuyên nghiệp"
                             target="_blank"><img style="filter:grayscale(100%);-webkit-filter: grayscale(100%);" src="http://huongsonht.jujube.com.vn/img/logo-footer.png" height="40"></a></div>

</div>