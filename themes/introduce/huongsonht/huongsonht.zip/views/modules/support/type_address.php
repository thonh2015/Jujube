<li class="support-item <?php echo "support-" . $data['type']; ?>">
    <i class="sp-icon"></i>
    <?php echo $data['address']; ?>
</li>