    <?php if ($show_widget_title) { ?>
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="title-main">
                    <h3><?php echo $widget_title; ?></h3>
                </div>
            </div>
        </div>
    <?php } ?>
    <?php if ($html) { ?>
                <?php echo $html; ?>
    <?php } ?>