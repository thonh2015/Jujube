<li class="support-item <?php echo "support-" . $data['type']; ?>">
    <a href="<?php echo $data['link'] ?>" target="_blank" rel="nofollow">
        <i class="sp-icon"></i>
        <span class="sp-title-content"><?php echo $data['title']; ?></span>
    </a>
</li>