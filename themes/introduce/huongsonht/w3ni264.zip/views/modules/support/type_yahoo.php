<li class="support-item <?php echo "support-" . $data['type']; ?>">
    <a href="ymsgr:<?php echo $data['nick'] ?>" rel="nofollow">
        <img src="http://opi.yahoo.com/online?u=<?php echo $data['nick'] ?>&m=g&t=5" border="0" class="sp-icon"/>
        <span class="sp-title-content"><?php echo $data['title']; ?></span>
    </a>
</li>