
 <div class="wrep">
		<div id="pageTitle2">
		    <div id="title" style="padding-top: 5px; text-transform: uppercase;">Tin Tức</div>
		</div>
		
		<table style="border: 0px solid rgb(197, 213, 231);" border="0" cellpadding="2" cellspacing="1" width="610">
			<tbody>
				<tr>
					<td style="padding-left: 5px;" align="left" valign="top" width="50%">
						<!--  danh sách 2 tin mới nhất -->
						<table bgcolor="#fff" border="0" cellpadding="0" cellspacing="1" width="98%">
							<tbody>
								<tr>
									<td>
									 <?php foreach ($hotnews as $ne) 
										//$link = Yii::app()->createUrl('news/news/detail', array('id' => $ne['news_id'], 'alias' => $ne['alias']));
										//$avatar = ClaHost::getImageHost() . $ne['image_path'] . 's150_150/' . $ne['image_name'];
									 { ?>
										<div style="width: 288px; border:1px solid rgb(197, 213, 231); margin: 2px; float:left;">
											<table width="100%" border="0" cellspacing="0" cellpadding="0">
												 <tbody>
													  <tr>
														<td class="img_home" rowspan="2" bgcolor="#f7fbfc" style="padding:5px;">
															<a href="<?php echo Yii::app()->createUrl('news/news/detail', array('id' => $ne['news_id'], 'alias' => $ne['alias'])) ?>" >
															<img src="<?php echo ClaHost::getImageHost() . $ne['image_path'] . 's150_150/' . $ne['image_name'] ?>" alt="" border="0" width="60" height="60">
															</a>
														</td>
														<td bgcolor="#f7fbfc" style="padding:5px;">
															<a href="<?php echo Yii::app()->createUrl('news/news/detail', array('id' => $ne['news_id'], 'alias' => $ne['alias'])) ?>"><?php echo $ne['news_title'] ?></a>															
														</td>
													  </tr>
													  <tr>								
													

												</tbody>
											</table>
										</div>					
					
									<?php } ?>
							
									  </td>
								</tr>

							</tbody>
						</table>
				<!--  danh sách 2 tin mới nhất -->
				</td>
			  </tr>
			</tbody>
	</table>
		
    </div>
  