<div class="statistic">
    <div class="panel panel-default">
        <?php if ($show_widget_title) { ?>
            <div class="panel-heading">
                <div class="title-main">
                <h3>
                    <?php echo $widget_title; ?>
                </h3>
                </div>
            </div>
        <?php } ?>
        <div class="panel-body">
            <div class="useraccess">
                <p class="text-info">
                    <span class="uc-title">&nbsp;&nbsp;&nbsp;<?php echo Yii::t('common', 'statistic_online'); ?></span>
                    <span class="uc-number"><?php echo number_format($online); ?></span>
                </p>
                <p class="text-info">
                    <span class="uc-title">&nbsp;&nbsp;&nbsp;<?php echo Yii::t('common', 'statistic_today') ;?></span>
                    <span class="uc-number"><?php echo number_format($today); ?></span>
                </p>
                <p class="text-primary">
                    <span class="uc-title">&nbsp;&nbsp;&nbsp;<?php echo Yii::t('common', 'statistic_totalaccess'); ?></span>
                    <span class="uc-number"><?php echo number_format($totalAccess); ?></span>
                </p>
            </div>
        </div>
    </div>
</div>